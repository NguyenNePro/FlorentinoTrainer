import SwiftUI

struct ContentView: View {
    @State private var autoDance = false
    @State private var autoPickup = false
    @State private var fixedDirection = true
    @State private var skillOneCue = true
    @State private var skillThreeCue = true
    @State private var selectedTab = 0
    @State private var selectedCombo = 0
    @State private var step = 0
    @State private var completed = 0
    @State private var sessionSeconds = 0
    @State private var showResetAlert = false

    private let combos = Combo.samples
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.035, green: 0.045, blue: 0.065), Color(red: 0.10, green: 0.035, blue: 0.045)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 0) {
                header
                if selectedTab == 0 { dashboard }
                else if selectedTab == 1 { training }
                else { stats }
                Spacer(minLength: 8)
                tabBar
            }
            .padding(.horizontal, 18)
        }
        .onReceive(timer) { _ in sessionSeconds += 1 }
        .alert("Đặt lại buổi tập?", isPresented: $showResetAlert) {
            Button("Hủy", role: .cancel) {}
            Button("Đặt lại", role: .destructive) { completed = 0; sessionSeconds = 0; step = 0 }
        } message: { Text("Thống kê buổi tập hiện tại sẽ được đặt lại.") }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text("AOV • TRAINING LAB").font(.system(size: 11, weight: .bold, design: .rounded)).tracking(2).foregroundStyle(.red.opacity(0.9))
                Text("FLORENTINO").font(.system(size: 27, weight: .black, design: .rounded))
            }
            Spacer()
            Image(systemName: "sparkles")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(Color(red: 1, green: 0.72, blue: 0.38))
                .frame(width: 44, height: 44)
                .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14))
        }
        .padding(.top, 12)
        .padding(.bottom, 18)
    }

    private var dashboard: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 14) {
                heroCard
                sectionTitle("THIẾT LẬP PHÒNG LUYỆN", subtitle: "Công tắc mô phỏng • Không điều khiển game")
                VStack(spacing: 0) {
                    ToggleRow(title: "Auto múa (mô phỏng)", detail: "Phát nhịp luyện chuỗi thao tác", value: $autoDance)
                    Divider().overlay(.white.opacity(0.08))
                    ToggleRow(title: "Gợi ý nhặt hoa", detail: "Hiện nhắc nhở trong bài tập", value: $autoPickup)
                    Divider().overlay(.white.opacity(0.08))
                    ToggleRow(title: "Cố định hướng", detail: "Giữ hướng hiển thị trong phòng tập", value: $fixedDirection)
                    Divider().overlay(.white.opacity(0.08))
                    ToggleRow(title: "Gợi ý chiêu 1", detail: "Đánh dấu bước dùng chiêu 1", value: $skillOneCue)
                    Divider().overlay(.white.opacity(0.08))
                    ToggleRow(title: "Gợi ý chiêu 3", detail: "Đánh dấu bước dùng chiêu 3", value: $skillThreeCue)
                }
                .padding(.horizontal, 14)
                .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 18))
                sectionTitle("BÀI TẬP NHANH", subtitle: "Chọn bài để bắt đầu luyện")
                ForEach(Array(combos.enumerated()), id: \.offset) { index, combo in
                    Button {
                        selectedCombo = index
                        step = 0
                        selectedTab = 1
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: combo.icon).font(.system(size: 19, weight: .bold)).foregroundStyle(.orange).frame(width: 42, height: 42).background(.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                            VStack(alignment: .leading, spacing: 4) {
                                Text(combo.name).font(.system(size: 15, weight: .bold)).foregroundStyle(.white)
                                Text(combo.subtitle).font(.system(size: 12)).foregroundStyle(.white.opacity(0.52))
                            }
                            Spacer()
                            Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.35))
                        }
                        .padding(12)
                        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 15))
                    }
                    .buttonStyle(.plain)
                }
                Text("Ứng dụng luyện tập độc lập, không đọc dữ liệu hoặc can thiệp Liên Quân Mobile.")
                    .font(.system(size: 11)).foregroundStyle(.white.opacity(0.38)).multilineTextAlignment(.center).padding(.top, 4)
            }
            .padding(.bottom, 14)
        }
    }

    private var heroCard: some View {
        ZStack(alignment: .bottomLeading) {
            RoundedRectangle(cornerRadius: 22).fill(LinearGradient(colors: [Color(red: 0.34, green: 0.10, blue: 0.12), Color(red: 0.12, green: 0.08, blue: 0.11), .black], startPoint: .topLeading, endPoint: .bottomTrailing))
            Circle().fill(.orange.opacity(0.13)).frame(width: 170).blur(radius: 2).offset(x: 210, y: -35)
            VStack(alignment: .leading, spacing: 9) {
                Text("FENCING • COMBO PRACTICE").font(.system(size: 9, weight: .heavy)).tracking(1.5).foregroundStyle(.orange)
                Text("Luyện nhịp\nFlorentino").font(.system(size: 25, weight: .black, design: .rounded))
                Text("Tập thao tác bằng hướng dẫn từng bước").font(.system(size: 12)).foregroundStyle(.white.opacity(0.65))
                HStack(spacing: 8) {
                    Label("3 bài tập", systemImage: "target")
                    Label("Offline", systemImage: "wifi.slash")
                }.font(.system(size: 10, weight: .semibold)).foregroundStyle(.white.opacity(0.7)).padding(.top, 3)
            }.padding(18)
        }
        .frame(height: 168)
        .clipShape(RoundedRectangle(cornerRadius: 22))
    }

    private var training: some View {
        let combo = combos[selectedCombo]
        return ScrollView(showsIndicators: false) {
            VStack(spacing: 15) {
                sectionTitle("PHÒNG LUYỆN", subtitle: combo.name)
                VStack(spacing: 12) {
                    HStack {
                        Text("TIẾN TRÌNH").font(.system(size: 10, weight: .bold)).tracking(1.4).foregroundStyle(.orange)
                        Spacer()
                        Text("\(min(step + 1, combo.steps.count))/\(combo.steps.count)").font(.system(size: 12, weight: .bold, design: .monospaced))
                    }
                    ProgressView(value: Double(min(step, combo.steps.count)), total: Double(combo.steps.count)).tint(.orange)
                    Text(step < combo.steps.count ? combo.steps[step].title : "Hoàn thành bài tập!").font(.system(size: 23, weight: .black, design: .rounded)).multilineTextAlignment(.center).frame(maxWidth: .infinity).padding(.vertical, 15)
                    Text(step < combo.steps.count ? combo.steps[step].detail : "Bạn đã hoàn thành chuỗi hướng dẫn. Hãy thử lại để luyện nhịp ổn định.").font(.system(size: 14)).foregroundStyle(.white.opacity(0.65)).multilineTextAlignment(.center).frame(minHeight: 55)
                    HStack(spacing: 10) {
                        cuePill("CHIÊU 1", active: skillOneCue)
                        cuePill("CHIÊU 3", active: skillThreeCue)
                        cuePill("NHẶT HOA", active: autoPickup)
                    }
                    Button {
                        if step < combo.steps.count { step += 1 }
                        if step == combo.steps.count { completed += 1 }
                    } label: {
                        Text(step < combo.steps.count ? "TIẾP THEO  →" : "HOÀN THÀNH ✓")
                            .font(.system(size: 14, weight: .black)).tracking(1)
                            .frame(maxWidth: .infinity).padding(.vertical, 16)
                            .background(LinearGradient(colors: [.orange, Color(red: 0.83, green: 0.25, blue: 0.16)], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 14))
                    }.buttonStyle(.plain)
                    Button("Bắt đầu lại bài này") { step = 0 }.font(.system(size: 12, weight: .semibold)).foregroundStyle(.white.opacity(0.55))
                }
                .padding(18)
                .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 20))
                sectionTitle("CHỌN BÀI TẬP", subtitle: "Chuyển giữa các chuỗi hướng dẫn")
                ForEach(Array(combos.enumerated()), id: \.offset) { index, item in
                    Button { selectedCombo = index; step = 0 } label: {
                        HStack {
                            Text(item.name).foregroundStyle(.white).font(.system(size: 14, weight: .bold))
                            Spacer()
                            if selectedCombo == index { Image(systemName: "checkmark.circle.fill").foregroundStyle(.orange) }
                        }.padding(14).background(.white.opacity(selectedCombo == index ? 0.10 : 0.04), in: RoundedRectangle(cornerRadius: 13))
                    }.buttonStyle(.plain)
                }
            }.padding(.bottom, 16)
        }
    }

    private var stats: some View {
        VStack(spacing: 16) {
            sectionTitle("THỐNG KÊ BUỔI TẬP", subtitle: "Dữ liệu chỉ lưu trong phiên sử dụng")
            HStack(spacing: 10) {
                StatCard(title: "BÀI HOÀN THÀNH", value: "\(completed)", icon: "checkmark.seal")
                StatCard(title: "THỜI GIAN", value: timeString, icon: "timer")
            }
            VStack(alignment: .leading, spacing: 10) {
                Text("MỤC TIÊU LUYỆN TẬP").font(.system(size: 11, weight: .bold)).tracking(1).foregroundStyle(.orange)
                Text("• Giữ nhịp thao tác ổn định\n• Nhớ thứ tự kỹ năng trong combo\n• Ôn lại từng bước trước khi vào trận").font(.system(size: 14)).foregroundStyle(.white.opacity(0.72)).lineSpacing(7)
            }.frame(maxWidth: .infinity, alignment: .leading).padding(16).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16))
            Button(role: .destructive) { showResetAlert = true } label: {
                Label("Đặt lại thống kê", systemImage: "arrow.counterclockwise").font(.system(size: 13, weight: .bold)).frame(maxWidth: .infinity).padding(14).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13))
            }
            Spacer()
        }.padding(.top, 4)
    }

    private var tabBar: some View {
        HStack(spacing: 0) {
            tab("square.grid.2x2.fill", "Tổng quan", 0)
            tab("scope", "Luyện combo", 1)
            tab("chart.bar.fill", "Thống kê", 2)
        }
        .padding(7).background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
        .padding(.bottom, 8)
    }

    private func tab(_ icon: String, _ title: String, _ index: Int) -> some View {
        Button { selectedTab = index } label: {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 16, weight: .bold))
                Text(title).font(.system(size: 10, weight: .semibold))
            }.foregroundStyle(selectedTab == index ? .orange : .white.opacity(0.48))
                .frame(maxWidth: .infinity).padding(.vertical, 8)
        }.buttonStyle(.plain)
    }

    private func sectionTitle(_ title: String, subtitle: String) -> some View {
        HStack(alignment: .lastTextBaseline) {
            Text(title).font(.system(size: 11, weight: .heavy)).tracking(1.1).foregroundStyle(.white.opacity(0.88))
            Spacer()
            Text(subtitle).font(.system(size: 9, weight: .medium)).foregroundStyle(.white.opacity(0.38))
        }.padding(.top, 5)
    }

    private func cuePill(_ title: String, active: Bool) -> some View {
        Text(title).font(.system(size: 9, weight: .heavy)).foregroundStyle(active ? .orange : .white.opacity(0.35))
            .padding(.horizontal, 9).padding(.vertical, 7)
            .background(active ? .orange.opacity(0.12) : .white.opacity(0.05), in: Capsule())
    }

    private var timeString: String {
        String(format: "%02d:%02d", sessionSeconds / 60, sessionSeconds % 60)
    }
}

struct ToggleRow: View {
    let title: String
    let detail: String
    @Binding var value: Bool
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 14, weight: .bold))
                Text(detail).font(.system(size: 10)).foregroundStyle(.white.opacity(0.45))
            }
            Spacer()
            Toggle(title, isOn: $value).labelsHidden().tint(.orange).scaleEffect(0.88, anchor: .trailing)
        }.padding(.vertical, 11)
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: icon).foregroundStyle(.orange).font(.system(size: 18))
            Text(value).font(.system(size: 28, weight: .black, design: .rounded))
            Text(title).font(.system(size: 9, weight: .bold)).tracking(0.8).foregroundStyle(.white.opacity(0.48))
        }.frame(maxWidth: .infinity, alignment: .leading).padding(16).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 17))
    }
}
