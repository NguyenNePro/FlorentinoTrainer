import Foundation

struct Combo {
    let name: String
    let subtitle: String
    let icon: String
    let steps: [PracticeStep]

    static let samples: [Combo] = [
        Combo(name: "Chuỗi làm quen", subtitle: "Ôn thứ tự thao tác cơ bản", icon: "figure.fencing", steps: [
            PracticeStep(title: "Quan sát mục tiêu", detail: "Dừng một nhịp, xác định hướng tiếp cận trong tình huống luyện tập."),
            PracticeStep(title: "Tập định hướng", detail: "Luyện thao tác di chuyển có kiểm soát, không vội chuyển bước."),
            PracticeStep(title: "Ôn kỹ năng", detail: "Đọc gợi ý kỹ năng trên màn hình và nhắc lại thứ tự sử dụng."),
            PracticeStep(title: "Kết thúc chuỗi", detail: "Đánh giá nhịp thao tác rồi bắt đầu lại nếu cần.")
        ]),
        Combo(name: "Nhịp nhặt hoa", subtitle: "Luyện quan sát và di chuyển", icon: "wind", steps: [
            PracticeStep(title: "Quan sát vị trí", detail: "Xác định điểm đánh dấu trong sơ đồ luyện tập."),
            PracticeStep(title: "Di chuyển đến điểm", detail: "Thực hành điều hướng chính xác và giữ nhịp ổn định."),
            PracticeStep(title: "Xác nhận bước", detail: "Chạm Tiếp theo khi đã hoàn tất thao tác mô phỏng.")
        ]),
        Combo(name: "Ôn chuỗi kỹ năng", subtitle: "Ghi nhớ nhịp chiêu 1 và chiêu 3", icon: "arrow.trianglehead.2.clockwise.rotate.90", steps: [
            PracticeStep(title: "Bước chuẩn bị", detail: "Đọc tình huống và xác định kỹ năng được nhắc."),
            PracticeStep(title: "Gợi ý chiêu 1", detail: "Ôn thời điểm sử dụng chiêu 1 trong bài tập mô phỏng."),
            PracticeStep(title: "Gợi ý chiêu 3", detail: "Ôn bước tiếp theo theo hướng dẫn của bài tập."),
            PracticeStep(title: "Tổng kết", detail: "Lặp lại chuỗi để ghi nhớ thứ tự và nhịp.")
        ])
    ]
}

struct PracticeStep {
    let title: String
    let detail: String
}
