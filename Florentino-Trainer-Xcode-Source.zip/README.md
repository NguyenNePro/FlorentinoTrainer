# Florentino Trainer — SwiftUI source

Ứng dụng luyện tập độc lập, không sửa đổi hoặc điều khiển Liên Quân Mobile.

## Có gì trong bản này
- Bảng thiết lập mô phỏng với các công tắc luyện tập.
- Ba bài tập hướng dẫn từng bước.
- Bộ đếm thời gian và số bài hoàn thành trong phiên.
- Giao diện tối, điểm nhấn đỏ/cam, tối ưu bố cục iPhone.

## Tạo IPA bằng Xcode
1. Trên máy Mac, mở Xcode và tạo project mới: **iOS > App**, Product Name `FlorentinoTrainer`, Interface `SwiftUI`, Language `Swift`.
2. Xóa file `ContentView.swift` và `App.swift` mẫu do Xcode tạo.
3. Kéo các file trong thư mục `FlorentinoTrainer/` vào project (chọn **Copy items if needed**).
4. Đặt Deployment Target theo iOS mà Xcode hỗ trợ trên máy; chọn iPhone làm thiết bị đích.
5. Trong **Signing & Capabilities**, chọn Team của bạn và một Bundle Identifier riêng, ví dụ `com.example.FlorentinoTrainer`.
6. Build để kiểm tra. Sau đó dùng **Product > Archive** hoặc **Distribute App** để xuất bản cài đặt phù hợp với chứng chỉ của bạn.

## Lưu ý quan trọng
- Đây là mã nguồn SwiftUI, không phải IPA đã biên dịch/ký.
- Chỉ có thể xuất IPA sau khi build bằng Xcode/macOS hoặc một dịch vụ build iOS phù hợp.
- Các công tắc là trạng thái giao diện/phòng luyện; không có chức năng macro, hack map, đọc bộ nhớ game, tự chạm màn hình hay né anti-cheat.
- Không nhập chứng chỉ, private key hoặc mật khẩu Apple vào cuộc trò chuyện.
